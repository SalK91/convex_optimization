# Chapter 1: Introduction and Overview

Optimization is the mathematical language of decision-making and learning. In machine learning and data science we constantly fit, estimate, or infer by minimizing a loss. Yet most real-world objectives are nonlinear and messy; solving them globally can be hard.

Convex optimization is the *tractable core* of this landscape. A convex problem has a single “bowl-shaped” valley, no false minima, so any local optimum is automatically global. That geometric simplicity gives us:

- mathematical guarantees of optimality,  
- efficient algorithms that scale,  
- robustness to noise and initialization.
 
> Convexity leads to robustness. Small perturbations to problem data typically result in small changes to the solution in convex optimization, a desirable feature in practice. Moreover, many approximation techniques (like convex relaxations of NP-hard problems) rely on solving a convex problem to get bounds or heuristic solutions for the original task. 


## 1.2 Canonical Convex Problem Form

A generic convex optimization problem can be written as:

$$
\begin{array}{ll}
\text{minimize}_{x} & f(x) \\
\text{subject to} & g_i(x) \le 0,\quad i = 1,\dots,m, \\
                  & h_j(x) = 0,\quad j = 1,\dots,p,
\end{array}
$$

where each $f$ and $g_i$ is convex, and each $h_j$ is affine (affine functions are both convex and concave).
 