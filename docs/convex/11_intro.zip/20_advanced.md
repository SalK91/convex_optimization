# Chapter 15: Advanced Large-Scale and Structured Methods

In Chapter 9 we focused on “classical convex solvers”: gradient methods, accelerated methods, Newton and quasi-Newton methods, projected/proximal methods, and interior-point methods. Those are the canonical tools of convex optimisation.
 
## 15.1 Coordinate descent and block coordinate descent

### 15.1.1 Idea

Instead of updating all coordinates of $x$ at once using a full gradient or Newton direction, we update one coordinate (or one block of coordinates) at a time, holding the others fixed.

Suppose we want to minimise a convex function
$$
\min_x F(x),
$$
and write $x = (x_1, x_2, \dots, x_p)$ in coordinates or blocks.  
Coordinate descent cycles through $i = 1,2,\dots,p$ and solves (or approximately solves)
$$
x_i^{(k+1)}
=
\arg\min_{z} \; F\big(x_1^{(k+1)}, \dots, x_{i-1}^{(k+1)}, z, x_{i+1}^{(k)}, \dots, x_p^{(k)}\big).
$$

In other words: update coordinate $i$ by optimising over just that coordinate (or block), treating the rest as constants.

### 15.1.2 Why this can be fast

- Each subproblem is often 1D (or low-dimensional), so it may have a closed form.
- For problems with separable structure — e.g. sums over features, or regularisers like $\|x\|_1 = \sum_i |x_i|$ — the coordinate update is extremely cheap.
- You never form the full gradient or solve a large linear system; you just operate on pieces.

This is especially attractive in high dimensions (millions of features), where a full Newton step would be absurdly expensive.

### 15.1.3 Convergence in convex problems

For many convex, continuously differentiable problems with certain regularity (e.g. strictly convex objective, or convex plus separable nonsmooth terms), cyclic coordinate descent is guaranteed to converge to the global minimiser. There are also randomized versions that pick a coordinate uniformly at random, which often give cleaner expected-rate guarantees.

For $\ell_1$-regularised least squares, i.e.
$$
\min_x \; \tfrac12 \|Ax - b\|_2^2 + \lambda \|x\|_1,
$$
each coordinate update becomes a scalar soft-thresholding step — so coordinate descent becomes an extremely efficient sparse regression solver.

### 15.1.4 Block coordinate descent

When coordinates are naturally grouped (for example, $x$ is really $(x^{(1)}, x^{(2)}, \dots)$ where each $x^{(j)}$ is a vector of parameters for a submodule or layer), we generalise to block coordinate descent. Each step solves
$$
x^{(j)} \leftarrow \arg\min_{z} F(\dots, z, \dots)\,.
$$

 
### 15.1.5 Use in nonconvex problems

Even when $F$ is not convex, people still run block coordinate descent (under names like “alternating minimisation” or “alternating least squares”), because:

- each block subproblem might be convex even if the joint problem isn’t,
- it is easy to implement,
- it often works “well enough” in practice.

You see this in low-rank matrix factorisation (recommender systems), where you fix all user factors and update item factors, then swap. There are no global guarantees in general (no convexity), but empirically it converges to useful solutions.

So:  

- In convex settings → provable global convergence.  
- In nonconvex settings → heuristic that often finds acceptable stationary points.

 
## 15.2 Stochastic gradient and mini-batch methods

### 15.2.1 Full gradient vs stochastic gradient

In Chapter 9, gradient descent uses the full gradient $\nabla f(x)$ at each step. In large-scale learning problems, $f$ is almost always an average over data:
$$
f(x) = \frac{1}{N} \sum_{i=1}^N \ell_i(x),
$$
where $\ell_i$ is the loss on sample $i$.

Computing $\nabla f(x)$ exactly costs $O(N)$ per step, which is huge.

Stochastic Gradient Descent (SGD) replaces $\nabla f(x)$ with an unbiased estimate. At each iteration we:

1. Sample $i$ uniformly from $\{1,\dots,N\}$,
2. Use $g_k = \nabla \ell_i(x_k)$,
3. Update
   $$
   x_{k+1} = x_k - \alpha_k g_k.
   $$

This is extremely cheap: one data point (or a small mini-batch) per step.

### 15.2.2 Convergence in convex problems

For convex problems, with diminishing step sizes $\alpha_k$, SGD converges to the global optimum in expectation, and more refined analyses show $O(1/\sqrt{k})$ suboptimality rates for general convex Lipschitz losses, improving to $O(1/k)$ in strongly convex smooth cases with appropriate averaging.

That is slower (per iteration) than deterministic gradient descent in theory, but each iteration is *much* cheaper. So SGD wins in wall-clock time for huge $N$.

### 15.2.3 Momentum, Adam, RMSProp (nonconvex practice, convex roots)

In modern machine learning, methods like momentum SGD, Adam, RMSProp, Adagrad, etc., are used routinely to train enormous nonconvex models (deep networks). These are variations of first-order methods with:

- adaptive step sizes,
- running averages of squared gradients,
- momentum terms.

While the most common use is for nonconvex problems, many of these methods (e.g. Adagrad-type adaptive steps, momentum acceleration) have their theoretical roots in convex optimisation and mirror-descent style analyses.

So stochastic first-order methods are:

- rigorous for convex problems,
- widely used heuristically for nonconvex problems.

Nonconvex landscapes feature saddles with negative curvature directions. Stochastic gradients and injected noise help escape strict saddles by perturbing iterates into descent directions. In overparameterized models, many local minima are near-global; under PL or error-bound conditions, GD enjoys linear convergence to global minima despite nonconvexity.

Variance-reduced methods like SVRG, SAGA, and SARAH restore linear convergence on strongly convex finite sums by periodically recomputing full gradients or maintaining per-sample memories. Adaptive schedules (cosine decay, one-cycle) automate learning-rate tuning. Gradient clipping limits exploding gradients; label smoothing, robust losses (Huber), and sample reweighting mitigate noise and outliers.


Adam maintains first and second moment estimates $m_t=\beta_1 m_{t-1}+(1-\beta_1) g_t$, $v_t=\beta_2 v_{t-1}+(1-\beta_2) g_t^2$, with bias-corrected updates $x_{t+1}=x_t-\eta \hat m_t/(\sqrt{\hat v_t}+\epsilon)$. AdamW decouples weight decay from the adaptive update. Adagrad accumulates squared gradients per coordinate; RMSProp uses exponential averaging; AdaBelief and Lion modify momentum rules; Adafactor lowers memory; Shampoo and K-FAC approximate curvature to precondition layers. Use decoupled regularization and warmup schedules to improve generalization.

## 15.3 ADMM: Alternating Direction Method of Multipliers

ADMM is one of the most important algorithms in modern convex optimisation for structured problems. It is used constantly in signal processing, sparse learning, distributed optimisation, and large-scale statistical estimation.

### 15.3.1 Problem form

ADMM solves problems of the form
$$
\min_{x,z} \; f(x) + g(z)
\quad
\text{subject to} \quad
Ax + Bz = c,
$$
where $f$ and $g$ are convex.

This form appears everywhere:

- $f$ is a data-fit term,
- $g$ is a regulariser or constraint indicator,
- $Ax + Bz = c$ ties them together.

For example, LASSO can be written by introducing a copy variable and enforcing $x=z$.

### 15.3.2 Augmented Lagrangian

ADMM applies the augmented Lagrangian method, which is like dual ascent but with a quadratic penalty on constraint violation. The augmented Lagrangian is
$$
\mathcal{L}_\rho(x,z,y)
=
f(x) + g(z)
+ y^\top (Ax + Bz - c)
+ \frac{\rho}{2} \|Ax + Bz - c\|_2^2,
$$
with dual variable (Lagrange multiplier) $y$ and penalty parameter $\rho>0$.

### 15.3.3 The ADMM updates (two-block case)

Iterate the following:
1. $x$-update:
   $$
   x^{k+1}
   :=
   \arg\min_x \mathcal{L}_\rho(x, z^k, y^k)
   $$
   (holding $z,y$ fixed).
2. $z$-update:
   $$
   z^{k+1}
   :=
   \arg\min_z \mathcal{L}_\rho(x^{k+1}, z, y^k).
   $$
3. Dual update:
   $$
   y^{k+1}
   :=
   y^k
   + \rho (A x^{k+1} + B z^{k+1} - c).
   $$

That is: optimise $x$ given $z$, optimise $z$ given $x$, then update the multiplier.

### 15.3.4 Why ADMM is powerful

- Each subproblem often becomes simple and separable:
  - The $x$-update might be a least-squares or a smooth convex minimisation,
  - The $z$-update might be a proximal operator (soft-thresholding, projection, etc.).
- You never have to solve the full coupled problem in one shot.
- ADMM is embarrassingly parallel / distributable: different blocks can be solved on different machines then averaged via the multiplier step.

### 15.3.5 Convergence

For convex $f$ and $g$, under mild assumptions (closed proper convex functions, some regularity), ADMM converges to a solution of the primal problem, and the dual variable $y^k$ converges to an optimal dual multiplier (Boyd and Vandenberghe, 2004, Ch. 5; also classical ADMM literature).

This is deeply tied to duality (Chapter 8): ADMM is best understood as a method of solving the dual with decomposability, but returning primal iterates along the way.

### 15.3.6 Use in nonconvex problems

In practice, ADMM is often extended to nonconvex problems by simply “pretending it’s fine.” Each subproblem is solved anyway, and the dual variable is updated the same way. The method is no longer guaranteed to find a global minimiser — but it often finds a stationary point that is good enough (e.g. in nonconvex regularised matrix completion, dictionary learning, etc.).

You will see ADMM used in imaging, sparse coding, variational inference, etc., even when parts of the model are not convex.

 
## 15.4 Proximal coordinate and coordinate-prox methods

There’s a natural fusion of the ideas in Sections 15.1 (coordinate descent) and 12.6 (proximal methods): proximal coordinate descent.

### 15.4.1 Problem form

Consider composite convex objectives
$$
F(x) = f(x) + R(x),
$$
with $f$ smooth convex and $R$ convex, possibly nonsmooth and separable across coordinates or blocks:
$$
R(x) = \sum_{j=1}^p R_j(x_j).
$$

### 15.4.2 Algorithm sketch

At each iteration, pick coordinate (or block) $j$, and update only $x_j$ by solving the 1D (or low-dim) proximal subproblem:
$$
x_j^{(k+1)}
=
\arg\min_{z}
\left[
\underbrace{
f\big(x_1^{(k+1)}, \dots, x_{j-1}^{(k+1)}, z, x_{j+1}^{(k)}, \dots \big)
}_{\text{local linear/quadratic approximation}}
+ R_j(z)
\right].
$$

Often we linearise $f$ around the current point in that block and add a quadratic term, just like a proximal gradient step but on one coordinate at a time.

### 15.4.3 Why it’s useful

- When $R$ is separable (e.g. $\ell_1$ sparsity penalties), each coordinate subproblem becomes a scalar shrinkage / thresholding step.
- Memory footprint is tiny.
- You get sparsity “for free” as many coordinates get driven to zero and stay there.
- Randomised versions (pick a coordinate at random) are simple and have good expected convergence guarantees in convex problems.

### 15.4.4 Use in nonconvex settings

People run proximal coordinate descent in nonconvex sparse learning (e.g. $\ell_0$-like surrogates, nonconvex penalties for variable selection). The convex convergence guarantees are gone, but empirically the method still often converges to a structured, interpretable solution.

 
## 15.5 Majorization–minimization (MM) and reweighted schemes

Majorization–minimization (MM) is a general pattern:

1. Build a simple convex surrogate that upper-bounds (majorises) your objective at the current iterate,
2. Minimise the surrogate,
3. Repeat.

It is sometimes called “iterative reweighted” or “successive convex approximation.”

### 15.5.1 MM template

Suppose we want to minimise $F(x)$ (convex or not). We construct $G(x \mid x^{(k)})$ such that:

- $G(x^{(k)} \mid x^{(k)}) = F(x^{(k)})$ (touches at current iterate),
- $G(x \mid x^{(k)}) \ge F(x)$ for all $x$ (majorises $F$),
- $G(\cdot \mid x^{(k)})$ is easy to minimise (often convex, often separable).

Then we set
$$
x^{(k+1)} \in \arg\min_x G(x \mid x^{(k)}).
$$

This guarantees $F(x^{(k+1)}) \le F(x^{(k)})$. So the objective is monotonically nonincreasing.

### 15.5.2 Iterative reweighted $\ell_1$ / $\ell_2$

A classical example: to promote sparsity or robustness, you might want to minimise something like
$$
\sum_i w_i(x) \, |x_i|
$$
or a concave penalty on residuals. You replace that concave / nonconvex penalty with a weighted convex penalty that depends on the previous iterate. Then you update the weights and solve again.

In the convex world, MM is just another way to design descent methods.  
In the nonconvex world, MM is a way to attack nonconvex penalties using a sequence of convex subproblems.

This is extremely common in robust regression, compressed sensing with nonconvex sparsity surrogates, and low-rank matrix recovery.

### 15.5.3 Relation to proximal methods

MM can often be interpreted as doing a proximal step on a locally quadratic or linearised upper bound. In that sense, it is philosophically close to proximal gradient (Chapter 9) and to Newton-like local quadratic approximation (Chapter 9), but with the additional twist that we are allowed to handle nonconvex $F$ as long as we *majorise* it with something convex.

 
## 15.6 Summary and perspective

We’ve now seen several algorithmic families that are particularly important at large scale and/or under structural constraints:

1. Coordinate descent / block coordinate descent 
    - Updates one coordinate block at a time.  
    - Converges globally for many convex problems.  
    - Scales extremely well in high dimensions.  
    - Used heuristically in nonconvex alternating minimisation.

2. Stochastic and mini-batch gradient methods  
    - Use noisy gradient estimates to get cheap iterations.  
    - Converge (in expectation) for convex problems.  
    - Power all of modern large-scale ML, including nonconvex deep learning.

3. ADMM (Alternating Direction Method of Multipliers)  
    - Splits a problem into simpler subproblems linked by linear constraints.  
    - Closely tied to duality and KKT (Chapters 7–8).  
    - Converges for convex problems.  
    - Used everywhere, including nonconvex settings, due to its modularity and parallelisability.

4. Proximal coordinate / coordinate-prox methods  
    - Merge sparsity-inducing penalties (Chapter 6) with blockwise updates.  
    - Ideal for $\ell_1$-type structure, group lasso, etc.  
    - Often extended to nonconvex penalties for even “more sparse” solutions.

5. Majorization–minimization (MM)  
    - Iteratively builds and minimises convex surrogates.  
    - Guarantees monotone descent of the true objective.  
    - Provides a clean bridge from convex optimisation theory into heuristic nonconvex optimisation.


- convex/11_intro.md → Chapter 01 and Chapter 02
- convex/12_vector.md → 1.5, 1.6, 1.7
 - convex/14_convexsets.md → 1.3, 2.2
- convex/15_convexfunctions.md → 1.3, 1.4
- convex/16_subgradients.md → 1.1, 1.4, 4.10
- convex/16a_optimality_conditions.md → 1.4, 6.01
- convex/17_kkt.md → 6.01, 6.05
- convex/18_duality.md → 6.04, 6.05
- convex/18a_pareto.md → 2.3, 10.04
- convex/18b_regularization.md → 02, 4.10, 6.02
- convex/19_optimizationalgo.md → 04, 05, 06
- convex/19a_optimization_constraints.md → 6.01, 6.05
- convex/19b_optimization_constraints.md → 6.01, 6.02, 6.05
- convex/20_advanced.md → 4.03–4.11, 5.01, 2.3
- convex/21_models.md → 02, 6.02
- convex/30_canonical_problems.md → 6.02, 02




# Chapter 4.05: GD – Multimodality and Saddle points


# Chapter 4.06: GD with Momentum
# Chapter 4.10: SGD Further Details


# Chapter 4.11: ADAM and friends
 
# Chapter 5.01: 


# Chapter 07: Derivative Free Optimization

When gradients are unavailable, unreliable, or prohibitively expensive, derivative-free methods optimize using only function evaluations. They are robust to noise, discontinuities, and simulation-based objectives but typically require more evaluations; restarting, adaptive sampling, and hybridizing with local smooth models improve efficiency.

# Chapter 7.01: Coordinate Descent

Coordinate descent updates one or blocks of coordinates while keeping others fixed, exploiting separability. For convex smooth functions with coordinate-wise Lipschitz constants, randomized selection achieves expected linear rates under strong convexity. For lasso, the update is soft-thresholding $w_i \leftarrow S_{\lambda/\|x_i\|^2}(w_i+\tfrac{x_i^\top r}{\|x_i\|^2})$, enabling scalable sparse learning; block variants support group lasso and structured sparsity.

# Chapter 7.02: Nelder-Mead

Nelder–Mead maintains a simplex of $n+1$ points, applying reflection, expansion, contraction, and shrink operations to move toward lower function values. It is simple and effective in low dimensions and under noise, though it lacks general convergence guarantees. Practical tips include restarts, adaptive shrinkage, and monitoring simplex size to declare convergence.

# Chapter 7.03: Simulated Annealing

Simulated annealing explores the landscape using a temperature schedule $T_k$; it accepts uphill moves of increase $\Delta$ with probability $\exp(-\Delta/T_k)$, allowing escape from local minima. With sufficiently slow cooling, global optimality is guaranteed in theory. In practice, neighborhood design, reheating, and hybrid local searches balance exploration and exploitation.

# Chapter 7.04: Multi-Starts

Multi-start strategies run local optimizers from diverse initial points generated via random sampling, low-discrepancy sequences, or Latin hypercubes. Clustering start points and adaptive allocation of budget to promising basins improve efficiency. Combining with trust-region methods yields robust performance on rugged objectives.

# Chapter 08: Evolutionary Algorithms

Population-based search evolves candidate solutions using variation and selection, handling nonconvexity, noise, and discrete or mixed variables naturally. They are highly parallel and excel when gradients are impractical, but require careful tuning of population size, mutation rates, and selection pressure to avoid premature convergence.

# Chapter 8.01: Introduction

An evolutionary loop samples offspring from parents via mutation and crossover, evaluates fitness, and selects survivors. Elitism preserves the best; fitness shaping, niching, and diversity maintenance prevent collapse. Termination by evaluation budget or stagnation is common; hybrid local search often sharpens final solutions.

# Chapter 8.02: ES / Numerical Encodings

Evolution Strategies represent solutions as real vectors and mutate with Gaussian noise. Step-size control (e.g., cumulative step-size adaptation) and covariance adaptation learn the search distribution’s scale and orientation, approximating natural gradient ascent on expected fitness. Variants like separable and limited-memory ES scale to higher dimensions by restricting covariance structure.

# Chapter 8.03: GA / Bit Strings

Genetic Algorithms encode solutions as bit strings or mixed encodings and use crossover to recombine building blocks and mutation to explore. Gray coding preserves locality; domain-specific operators exploit structure in combinatorial problems. Selection schemes (tournament, rank-based) balance exploration and exploitation.

# Chapter 8.04: CMA-ES Algorithm

CMA-ES samples $x\sim \mathcal{N}(m,\sigma^2 C)$, updates the mean $m$ using weighted elites, adapts global step $\sigma$ via a cumulative path, and updates covariance $C$ using rank-one and rank-$\mu$ terms. It is invariant to scaling and rotations, robust to noise, and strong on ill-conditioned problems up to medium dimensions; diagonal and limited-memory variants extend scale, and restarts with increasing population sizes improve reliability.

# Chapter 8.05: CMA-ES Algorithm Wrap Up

Effective practice includes population sizes proportional to dimension, active covariance updates, elitist selection on rugged landscapes, restart strategies, and hybridization with local gradient-based refinements when available. Constraint handling uses rejection, repair, or adaptive penalization; noisy objectives benefit from resampling and uncertainty handling.

# Chapter 10: Bayesian Optimization

Bayesian optimization targets expensive black-box functions by fitting a probabilistic surrogate and selecting new evaluations via acquisition functions that balance exploration and exploitation. It is sample-efficient, accommodates noise, and supports constraints, multiple fidelities, and multiple objectives, making it ideal for hyperparameter tuning and system design.

# Chapter 10.01: Black Box Optimization

Given data $\mathcal{D}=\{(x_i,y_i)\}$ with $y_i=f(x_i)+\epsilon$, fit a surrogate posterior $p(f\,|\,\mathcal{D})$ and choose $x_{t+1}\in\arg\max_x a(x;\mathcal{D})$. The acquisition $a$ depends on posterior mean $\mu(x)$ and uncertainty $\sigma(x)$. After evaluating $y_{t+1}$, update $\mathcal{D}$ and repeat. Constraints are modeled by feasibility surrogates, yielding a product acquisition that discounts infeasible regions.

# Chapter 10.02: Basic BO Loop and Surrogate Modelling

Initialization uses space-filling designs. Gaussian processes with kernels (RBF, Matérn) provide calibrated uncertainty; scaling tricks include input warping, ARD, and whitening. Alternatives include tree Parzen estimators, random forest surrogates, Bayesian neural networks, and deep kernel learning. For high dimensions, trust-region BO restricts to local subspaces; additive kernels and embeddings reduce effective dimension; batch BO selects multiple points per iteration by penalization or joint optimization.

# Chapter 10.03: Posterior Uncertainty and Acquisition Functions I

With GP posteriors, common acquisitions are
$
\operatorname{UCB}(x)=\mu(x)+\kappa \sigma(x),\quad
\operatorname{EI}(x)=\mathbb{E}[(f^\star - f(x))_+],\quad
\operatorname{PI}(x)=\mathbb{P}(f(x)\le f^\star - \xi).
$
Thompson sampling samples a function from the posterior and optimizes it. Batch acquisitions (q-EI, q-UCB) pick sets by joint normal approximations or fantasy models. Noisy settings integrate observation noise; constraints multiply $a(x)$ by feasibility probabilities.

# Chapter 10.04: Posterior Uncertainty and Acquisition Functions II

Advanced BO includes trust-region methods that expand or contract local regions based on success, multi-fidelity BO that trades accuracy and cost via co-kriging or bandit-inspired schedules, multi-objective BO maximizing expected hypervolume improvement, preference-based BO from pairwise comparisons, and safe BO that respects safety constraints by maintaining high-probability safe sets.

# Chapter 10.05: Important Surrogate Models

Gaussian processes offer exact posteriors with cubic scaling; sparse GPs use inducing points to scale, and random feature or NTK approximations connect to deep networks. Tree-based TPE/SMAC handle mixed discrete–continuous spaces and conditional parameters well. Deep ensembles and last-layer Bayesian linear models provide scalable uncertainty proxies. At extreme scales, neural surrogates with uncertainty proxies integrated into trust-region BO maintain efficiency and robustness.

